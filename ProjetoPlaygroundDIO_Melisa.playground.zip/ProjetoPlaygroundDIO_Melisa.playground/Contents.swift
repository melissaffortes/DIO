import UIKit

let name = "Steve"

var lastName: String?
lastName = "Jobs"

print(name, lastName)

lastName = "Wozniak"

print(name, lastName)


if let theLastName = lastName {
   print("The last name is  \(theLastName)")
} else {
   print("No last name found")
}
